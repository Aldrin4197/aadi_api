# AADI Laravel + Vue hero integration

This package adapts the supplied HomeHero.vue and the floating, shared-shape Three.js prototype.

## Install

1. Back up your existing HomeHero.vue.
2. Put all three files below in the SAME directory as your existing HomeHero.vue, CityPicker.vue, and SearchIcon.vue:
   - HomeHero.vue — replace your existing component with this updated version.
   - AadiHeroScene.vue — new canvas component.
   - aadiHeroScene.js — complete scene/model/morph engine.
3. Run these commands from your Laravel project root:

```bash
npm install --save-exact three@0.170.0
npm run dev
```

For production, build with `npm run build` and deploy the generated Vite assets using your existing deployment workflow. Keep package.json and the lockfile changes. If Three.js is already used elsewhere, check its required version before changing that dependency.

No iframe, import map, database migration, or new Laravel route is needed. Vite bundles the pinned Three.js dependency; the canvas code loads after the Vue component mounts.

## Category wiring

| Existing HomeHero key | Rendered model |
| --- | --- |
| spaces | Rental room |
| haul | Utility vehicle |
| raketeer | Service workshop |

The existing category names remain in the search and locate events. AadiHeroScene watches its category prop and morphs the same persistent meshes when it changes. Do not add `:key="active"` to the scene component: that would recreate it on every selection and prevent the morph.

The only visual replacement in HomeHero is:

```vue
<AadiHeroScene
    :category="active"
    :fallback-src="`/images/illustrations/${scene.image}.svg`"
    :label="scene.label"
/>
```

Its import is `import AadiHeroScene from './AadiHeroScene.vue';`.

## Existing project requirements

Keep CityPicker.vue, SearchIcon.vue, the current site styles (including aadi-hero and hero-scene), and the existing SVGs at:

- public/images/illustrations/space-studio.svg
- public/images/illustrations/vehicle-van.svg
- public/images/illustrations/raket-repair.svg

The SVGs appear while the 3D module loads and if WebGL is unavailable. Search, location, captions, and busy handling use the supplied component logic. This package does not include those existing components, assets, or the full Laravel application.

## Lifecycle and controls

The component supports drag and arrow-key rotation, gentle idle float/rotation, pause/resume, and reduced motion. Initialization runs after mounting, and disposal removes event listeners, disconnects observers, stops animation frames, and frees geometries/materials and the renderer. KeepAlive deactivation suspends rendering.

Do a visual check within your actual site after integration, especially if global hero-scene styles enforce a fixed height or clip children. If the scene is blank, check the browser console and confirm the Vite build completed and the three dependency was installed.

Validation performed on the package: Vue SFC compilation and scripted scene lifecycle/category-change checks. The full Laravel app and its global styles were not available for a browser integration check.
