<script setup>
import { ref } from 'vue';
import AadiVerifiedBadge from './components/AadiVerifiedBadge.vue';
import AadiPlusBadge from './components/AadiPlusBadge.vue';
import AadiRecommendedBadge from './components/AadiRecommendedBadge.vue';
import AadiStatusBadge from './components/AadiStatusBadge.vue';
import { statusBadges } from './components/statusBadges.js';
const variant = ref('pill');
const size = ref('md');
const iconStyle = ref('filled');
const verified = ref(true);
const profiles = [
  { role: 'user', label: 'User', name: 'Sam Rivera', initials: 'SR', description: 'A verified member of the community.' },
  { role: 'landlord', label: 'Landlord', name: 'Mika Lorenzo', initials: 'ML', description: 'A place for your next chapter.' },
  { role: 'vehicle-owner', label: 'Vehicle owner', name: 'Jules Cruz', initials: 'JC', description: 'Ready for the road ahead.' },
  { role: 'raketeer', label: 'Raketeer', name: 'Alex Reyes', initials: 'AR', description: 'Skills that get things done.' },
];
</script>

<template>
  <main class="badge-preview">
    <header class="page-header">
      <a class="wordmark" href="#" aria-label="Aadi badge preview">aadi<span aria-hidden="true">✳</span></a>
      <span class="header-note">The Aadi badge collection</span>
    </header>

    <section class="intro">
      <div><p class="eyebrow">People behind the possibilities</p><h1>A distinct role.<br>A familiar mark.</h1></div>
      <p class="intro-copy">One community. A mark for every role.<br>Designed to feel at home on every profile.</p>
    </section>

    <section class="collection" aria-label="Aadi user and role verification badges">
      <article v-for="profile in profiles" :key="profile.role" class="role-card" :class="`role-card--${profile.role}`">
        <div class="seal-stage"><AadiVerifiedBadge :role="profile.role" :icon-style="iconStyle" verified variant="emblem" size="lg"/></div>
        <p>{{ profile.description }}</p>
        <div class="icon-comparison"><div><AadiVerifiedBadge :role="profile.role" verified variant="icon" icon-style="outline" size="lg"/><span>Gray outline</span></div><div><AadiVerifiedBadge :role="profile.role" verified variant="icon" icon-style="filled" size="lg"/><span>Full color</span></div></div>
        <div class="pill-stage"><AadiVerifiedBadge :role="profile.role" :icon-style="iconStyle" verified size="sm"/></div>
      </article>
    </section>

    <section class="plus-showcase" aria-labelledby="plus-heading">
      <div class="plus-intro"><span class="future-label">Future edition</span><h2 id="plus-heading">Meet Aadi Plus.</h2><p>A signature plus, in a rounded diamond.<br>A distinct mark for the next Aadi edition.</p><div class="plus-pair"><AadiPlusBadge active icon-style="outline"/><AadiPlusBadge active icon-style="filled"/></div></div>
      <div class="plus-compare"><div><AadiPlusBadge active variant="emblem" size="lg" icon-style="outline"/><span>Gray outline</span></div><div><AadiPlusBadge active variant="emblem" size="lg" icon-style="filled"/><span>Full color</span></div></div>
    </section>

    <section class="plus-showcase recommended-showcase" aria-labelledby="recommended-heading">
      <div class="plus-intro"><span class="future-label">The recommendation mark</span><h2 id="recommended-heading">Aadi Recommended.</h2><p>A star medallion for the Aadi recommendation.<br>Gray in outline. Solid gold in full color.</p><div class="plus-pair"><AadiRecommendedBadge active icon-style="outline"/><AadiRecommendedBadge active icon-style="filled"/></div></div>
      <div class="plus-compare recommended-compare"><div><AadiRecommendedBadge active variant="emblem" size="lg" icon-style="outline"/><span>Gray outline</span></div><div><AadiRecommendedBadge active variant="emblem" size="lg" icon-style="filled"/><span>Full color</span></div></div>
    </section>

    <section class="status-collection" aria-labelledby="status-heading">
      <div class="section-heading"><div><h2 id="status-heading">More ways to stand out</h2><p>Listing and profile badges, in gray outline and full color.</p></div></div>
      <div class="status-grid"><article v-for="(status, type) in statusBadges" :key="type" class="status-card">
        <AadiStatusBadge :type="type" active variant="emblem" :icon-style="iconStyle"/>
        <div class="status-comparison"><div><AadiStatusBadge :type="type" active icon-style="outline" size="sm"/><span>Gray outline</span></div><div><AadiStatusBadge :type="type" active icon-style="filled" size="sm"/><span>Full color</span></div></div>
      </article></div>
    </section>

    <section class="playground" aria-labelledby="preview-heading">
      <div class="section-heading"><div><h2 id="preview-heading">See it on a profile</h2><p>Switch the style and size to find the right fit.</p></div><span class="sample-label">Sample profiles</span></div>
      <div class="toolbar">
        <div class="controls">
          <fieldset><legend>Icon style</legend><div class="segmented"><button v-for="v in ['outline','filled']" :key="v" type="button" :aria-pressed="iconStyle === v" @click="iconStyle = v">{{ v === 'outline' ? 'Outline' : 'Filled' }}</button></div></fieldset>
          <fieldset><legend>Style</legend><div class="segmented"><button v-for="v in ['pill','emblem','icon']" :key="v" type="button" :aria-pressed="variant === v" @click="variant = v">{{ { pill: 'Pill', emblem: 'Emblem', icon: 'Icon only' }[v] }}</button></div></fieldset>
          <fieldset><legend>Size</legend><div class="segmented"><button v-for="v in ['sm','md','lg']" :key="v" type="button" :aria-pressed="size === v" @click="size = v">{{ { sm: 'Small', md: 'Medium', lg: 'Large' }[v] }}</button></div></fieldset>
        </div>
        <label class="visibility-toggle"><input type="checkbox" v-model="verified"><span>Verified status</span></label>
      </div>
      <div class="examples">
        <article v-for="profile in profiles" :key="profile.role" class="profile" :class="`profile--${profile.role}`">
          <div class="profile-header"><div class="avatar" aria-hidden="true">{{ profile.initials }}</div><div class="profile-info"><h3>{{ profile.name }}</h3><p>{{ profile.label }}</p></div></div>
          <div class="profile-stage"><AadiVerifiedBadge :role="profile.role" :icon-style="iconStyle" :variant="variant" :size="size" :verified="verified"/><p v-if="!verified" class="empty">No verification badge</p></div>
        </article>
      </div>
      <div class="plus-live"><div><h3>Plus edition</h3><p>Uses the selected style, size, and color treatment.</p></div><div class="plus-live-stage"><AadiPlusBadge active :variant="variant" :size="size" :icon-style="iconStyle"/></div></div>
      <div class="plus-live"><div><h3>Aadi Recommended</h3><p>Uses the selected style, size, and color treatment.</p></div><div class="plus-live-stage"><AadiRecommendedBadge active :variant="variant" :size="size" :icon-style="iconStyle"/></div></div>
      <div class="status-live"><h3>Listing badges</h3><p>All five follow the selected style, size, and color treatment.</p><div><AadiStatusBadge v-for="(status, type) in statusBadges" :key="type" :type="type" active :variant="variant" :size="size" :icon-style="iconStyle"/></div></div>
      <div class="combined-example"><span>On the same profile</span><div><AadiVerifiedBadge role="landlord" verified :icon-style="iconStyle"/><AadiPlusBadge active :icon-style="iconStyle"/><AadiRecommendedBadge active :icon-style="iconStyle"/></div></div>
    </section>
    <footer><span>User verification, role verification, Plus, and Recommended are independent.</span><span>Spaces. Rides. Skills.</span></footer>
  </main>
</template>

<style>
* { box-sizing: border-box; }
body { margin: 0; background: #f7f7f8; color: #27272a; font-family: 'Avenir Next', 'Segoe UI', sans-serif; -webkit-font-smoothing: antialiased; }
.badge-preview { max-width: 1200px; padding: 0 40px; margin: auto; }
.page-header { display: flex; align-items: center; justify-content: space-between; gap: 24px; padding: 24px 0; border-bottom: 1px solid #dedee2; }
.wordmark { display: inline-flex; align-items: center; color: #27272a; font-size: 36px; font-weight: 800; letter-spacing: -2px; line-height: 1; text-decoration: none; }
.wordmark span { margin-left: 5px; font-size: 25px; color: #23816e; }
.header-note, .sample-label { font-size: 12px; color: #71717a; }
.intro { display: flex; align-items: flex-end; justify-content: space-between; gap: 32px; padding: 42px 0 32px; }
.eyebrow { margin: 0 0 14px; font-size: 12px; font-weight: 600; color: #71717a; }
h1 { margin: 0; font-size: clamp(34px, 4vw, 48px); line-height: 1.1; letter-spacing: -1.7px; font-weight: 650; }
.intro-copy { margin: 0 0 3px; color: #71717a; font-size: 14px; line-height: 1.75; }
.collection { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); border: 1px solid #dedee2; border-radius: 20px; background: #fff; overflow: hidden; }
.role-card { display: flex; flex-direction: column; align-items: center; text-align: center; padding: 32px 16px 24px; min-width: 0; }
.role-card + .role-card { border-left: 1px solid #e4e4e7; }
.seal-stage { display: flex; justify-content: center; align-items: center; min-height: 181px; }
.role-card > p { font-size: 12px; color: #71717a; line-height: 1.5; margin: 17px 0 22px; }
.icon-comparison { display: flex; gap: 26px; justify-content: center; margin: 0 0 20px; }
.icon-comparison > div { display: flex; flex-direction: column; align-items: center; gap: 7px; }
.icon-comparison > div > span:last-child { font-size: 10px; color: #71717a; }
.pill-stage { display: flex; justify-content: center; margin-top: auto; width: 100%; padding-top: 20px; border-top: 1px solid #ededf0; }
.playground { margin: 36px 0 0; }
.section-heading { display: flex; align-items: center; justify-content: space-between; gap: 20px; }
h2 { margin: 0 0 7px; font-size: 22px; font-weight: 650; letter-spacing: -.5px; }
.section-heading p { margin: 0; color: #71717a; font-size: 13px; line-height: 1.5; }
.toolbar { display: flex; align-items: center; justify-content: space-between; gap: 24px; margin: 22px 0 18px; padding: 16px 20px; border: 1px solid #dedee2; border-radius: 12px; background: #f0f0f2; }
.controls { display: flex; align-items: center; flex-wrap: wrap; gap: 24px; }
fieldset { border: 0; padding: 0; margin: 0; min-width: 0; }
legend { padding: 0; font-size: 11px; color: #71717a; margin-bottom: 7px; font-weight: 600; }
.segmented { display: flex; gap: 2px; padding: 3px; background: #e4e4e7; border-radius: 8px; }
button { appearance: none; border: 0; border-radius: 6px; padding: 8px 13px; font-family: inherit; font-size: 12px; font-weight: 600; line-height: 1.25; color: #52525b; background: transparent; cursor: pointer; min-height: 34px; transition: background-color .15s, color .15s; white-space: nowrap; }
button:hover { background: #d4d4d8; }
button[aria-pressed='true'] { background: #27272a; color: #fff; }
:focus-visible { outline: 3px solid #337faa; outline-offset: 3px; }
.visibility-toggle { display: inline-flex; align-items: center; gap: 9px; cursor: pointer; font-size: 12px; font-weight: 600; white-space: nowrap; padding: 12px 0; }
.visibility-toggle input { width: 18px; height: 18px; margin: 0; accent-color: #196653; }
.examples { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
.profile { background: #fff; border: 1px solid #dedee2; border-radius: 14px; padding: 20px; min-width: 0; }
.profile-header { display: flex; align-items: center; gap: 12px; }
.avatar { flex: 0 0 42px; width: 42px; height: 42px; display: grid; place-items: center; border-radius: 50%; background: #e4e4e7; color: #52525b; font-size: 12px; font-weight: 700; }
.profile--vehicle-owner .avatar { background: #e4e4e7; color: #52525b; }
.profile--raketeer .avatar { background: #e4e4e7; color: #52525b; }
.profile-info { min-width: 0; }
h3 { margin: 0 0 5px; font-size: 14px; line-height: 1.25; font-weight: 650; overflow-wrap: anywhere; }
.profile-info p { margin: 0; color: #71717a; font-size: 12px; }
.profile-stage { display: flex; align-items: center; justify-content: center; min-height: 206px; padding-top: 16px; }
.empty { font-size: 12px; color: #71717a; margin: 0; }
footer { display: flex; justify-content: space-between; gap: 16px; padding: 24px 0; margin-top: 26px; border-top: 1px solid #dedee2; color: #71717a; font-size: 11px; line-height: 1.5; }
.plus-showcase { margin-top: 24px; padding: 30px 34px; background: #fff; border: 1px solid #dedee2; border-radius: 20px; display: grid; grid-template-columns: 1fr 1fr; align-items: center; gap: 28px; }
.future-label { display: inline-block; color: #71717a; font-size: 11px; margin-bottom: 14px; }
.plus-intro h2 { font-size: 28px; margin: 0 0 12px; }
.plus-intro p, .plus-live p { margin: 0; color: #71717a; font-size: 13px; line-height: 1.6; }
.plus-pair { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 22px; }
.plus-compare { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px; }
.plus-compare > div { display: flex; flex-direction: column; align-items: center; gap: 18px; }
.plus-compare > div > span:last-child { color: #71717a; font-size: 11px; }
.plus-live { margin-top: 16px; padding: 20px 24px; border: 1px solid #dedee2; border-radius: 14px; background: #fff; display: flex; align-items: center; justify-content: space-between; gap: 24px; }
.plus-live-stage { min-width: 150px; min-height: 175px; display: flex; align-items: center; justify-content: center; }
.combined-example { display: flex; flex-wrap: wrap; align-items: center; gap: 18px; padding: 22px 0 0; }
.combined-example > span { font-size: 12px; color: #71717a; }
.combined-example > div { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; }
.status-collection { margin-top: 36px; }
.status-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr)); gap: 16px; margin-top: 20px; }
.status-card { min-width: 0; display: flex; flex-direction: column; align-items: center; gap: 26px; padding: 26px 18px; border: 1px solid #dedee2; background: #fff; border-radius: 16px; }
.status-comparison { display: flex; flex-wrap: wrap; justify-content: center; gap: 18px; width: 100%; padding-top: 20px; border-top: 1px solid #ededf0; }
.status-comparison > div { display: flex; flex-direction: column; align-items: center; gap: 8px; }
.status-comparison > div > span:last-child { font-size: 10px; color: #71717a; }
.status-live { background: #fff; border: 1px solid #dedee2; border-radius: 14px; padding: 24px; margin-top: 16px; }
.status-live > p { font-size: 13px; line-height: 1.6; color: #71717a; margin: 0; }
.status-live > div { display: flex; flex-wrap: wrap; align-items: center; gap: 24px; margin-top: 22px; }
@media (min-width: 701px) and (max-width: 1000px) { .recommended-showcase { grid-template-columns: 1fr; } }
@media (max-width: 420px) { .recommended-compare { grid-template-columns: 1fr; gap: 28px; } }
@media (max-width: 700px) { .plus-showcase { grid-template-columns: 1fr; padding: 24px 20px; gap: 32px; } .plus-live { flex-direction: column; align-items: flex-start; } .plus-live-stage { width: 100%; } .plus-compare { gap: 10px; } }
@media (max-width: 1000px) { .badge-preview { padding: 0 24px; } .profile { padding: 16px 10px; } .profile-header { padding: 0 4px; } }
@media (max-width: 850px) { .intro { align-items: flex-start; flex-direction: column; gap: 18px; } .intro-copy br { display: none; } .examples { grid-template-columns: 1fr; } .profile { padding: 20px; } .profile-stage { min-height: 206px; } .toolbar { flex-wrap: wrap; gap: 12px; } .role-card { padding: 28px 8px 20px; } .collection .aadi-badge--lg { --ab-seal: 96px; --ab-title: 17px; } }
@media (max-width: 620px) { .badge-preview { padding: 0 20px; } .collection { grid-template-columns: 1fr; } .role-card { padding: 28px 22px; } .role-card + .role-card { border-left: 0; border-top: 1px solid #e4e4e7; } .collection .aadi-badge--lg { --ab-seal: 120px; --ab-title: 20px; } .toolbar { padding: 16px; } .controls { gap: 16px; } .sample-label { display: none; } footer { flex-direction: column; gap: 5px; } }
.collection { grid-template-columns: repeat(4, minmax(0, 1fr)); }
.role-card > p { min-height: 36px; }
.examples { grid-template-columns: repeat(2, minmax(0, 1fr)); }
@media (max-width: 1000px) {
  .collection { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .collection .role-card { border: 0; }
  .collection .role-card:nth-child(even) { border-left: 1px solid #e4e4e7; }
  .collection .role-card:nth-child(n+3) { border-top: 1px solid #e4e4e7; }
}
@media (max-width: 620px) {
  .collection, .examples { grid-template-columns: 1fr; }
  .collection .role-card:nth-child(even) { border-left: 0; }
  .collection .role-card + .role-card { border-top: 1px solid #e4e4e7; }
  .role-card > p { min-height: 0; }
}
@media (prefers-reduced-motion: reduce) { button { transition: none; } }
</style>
