# Aadi verified badges — Vue 3

Custom SVG verification seals for users, landlords, vehicle owners, and raketeers. No icon libraries, external images, fonts, Tailwind dependency, or runtime network calls. Scoped component CSS works with Laravel + Vue and Tailwind 4.

## Open the preview

Double-click `preview.html` for the standalone interactive preview. It includes Vue and all styles, so no install or internet connection is required.

## Run the development preview

```sh
npm install
npm run dev
```

Build: `npm run build`. Serve `dist/` with any static server. Open the Vue preview to change style, size, and verification visibility.

## Use in your existing Vue app

Copy `src/components/AadiVerifiedBadge.vue` into your components directory.

```vue
<script setup>
import AadiVerifiedBadge from './components/AadiVerifiedBadge.vue';
defineProps({ user: { type: Object, required: true } });
</script>

<template>
  <AadiVerifiedBadge role="user" :verified="user.is_verified === true" />
  <AadiVerifiedBadge role="landlord" :verified="user.landlord_verified === true" />
  <AadiVerifiedBadge role="vehicle-owner" :verified="user.vehicle_owner_verified === true" />
  <AadiVerifiedBadge role="raketeer" :verified="user.raketeer_verified === true" />
</template>
```

These field names are examples; map them to your API. Use independent approved verification status per role, supplied by your backend. The component defaults to hidden when `verified` is omitted or false. It only displays a badge; approval and authorization belong to your server.

| Prop | Values | Default |
| --- | --- | --- |
| role | user / landlord / vehicle-owner / raketeer | Required |
| verified | Boolean | false |
| iconStyle | outline / filled | outline |
| variant | pill / emblem / icon | pill |
| size | sm / md / lg | md |

`emblem` is the larger profile seal, `pill` fits beside names, and `icon` is compact. All variants have an accessible role-specific label and a native hover title. Icons and text distinguish roles without relying on color. Unsupported roles render nothing. The component inherits your app's font. Adjust the color entries in its `roles` object to match your final brand palette.

Demo profiles and the typographic Aadi wordmark in App.vue are illustrative, not imported brand assets. No verification guarantees, ratings, or document checks are implied by the artwork.

## Outline and filled icons

Both drawings are custom SVG paths, with identical containers and sizing. The filled version has cutout details rather than filling the open outline paths. Switch them with `icon-style` in every badge variant:

```vue
<AadiVerifiedBadge role="landlord" :verified="true" icon-style="outline" />
<AadiVerifiedBadge role="vehicle-owner" :verified="true" icon-style="filled" />
<AadiVerifiedBadge role="raketeer" :verified="true" variant="icon" icon-style="filled" />
```

The preview shows both icon styles side by side and has a global Outline / Filled control.

## Color treatment

`icon-style="outline"` uses neutral gray outlines, gray text, and a transparent background. `icon-style="filled"` uses a solid cyan, emerald, blue, or amber seal with a white icon; pill backgrounds are solid role color with white text. The emblem label below the seal stays in the role color for readability on light backgrounds. Both styles indicate verification; gray is a visual style, not an unverified status.

## Aadi Plus — future edition

Copy `src/components/AadiPlusBadge.vue` into your project. This is an edition badge, independent of role verification. It uses a rounded diamond and plus symbol, without a verification check. The outline is gray; the filled badge is solid violet with a white plus. No subscription logic, pricing, or future benefits are implemented.

```vue
<script setup>
import AadiPlusBadge from './components/AadiPlusBadge.vue';
defineProps({ user: { type: Object, required: true } });
</script>

<template>
  <AadiPlusBadge :active="user.has_aadi_plus === true" icon-style="filled" />
</template>
```

`has_aadi_plus` is an example field. Map it to your future server-supplied edition entitlement. `active` defaults to `false`, hiding the badge. Preview examples explicitly set it to true.

| Prop | Values | Default |
| --- | --- | --- |
| active | Boolean | false |
| iconStyle | outline / filled | filled |
| variant | pill / emblem / icon | pill |
| size | sm / md / lg | md |

The preview shows both Plus color treatments, a live version controlled by the existing selectors, and Plus beside a verified landlord badge.

## Aadi Recommended

Copy `src/components/AadiRecommendedBadge.vue` into your project. The recommendation badge uses a star medallion with a neutral gray outline or a solid gold background and white star. It supports pill, emblem, and icon forms at sm, md, and lg sizes.

```vue
<script setup>
import AadiRecommendedBadge from './components/AadiRecommendedBadge.vue';
defineProps({ listing: { type: Object, required: true } });
</script>

<template>
  <AadiRecommendedBadge :active="listing.is_aadi_recommended === true" icon-style="filled" />
</template>
```

`is_aadi_recommended` is an example backend field. The component displays a designation; recommendation criteria and assignment are not implemented. Keep this flag independent of verification and Aadi Plus.

| Prop | Values | Default |
| --- | --- | --- |
| active | Boolean | false |
| iconStyle | outline / filled | filled |
| variant | pill / emblem / icon | pill |
| size | sm / md / lg | md |

The preview shows the two color treatments, responds to the existing style controls, and includes all three badge types on one sample profile.

## Listing and profile status badges

Copy **both** `src/components/AadiStatusBadge.vue` and `src/components/statusBadges.js` to the same components folder. One reusable component supports these five types:

| Type | Label | Symbol | Filled color |
| --- | --- | --- | --- |
| top-rated | Top Rated | Trophy | Bronze gold |
| featured | Featured | Sparkles | Magenta |
| new | New | Sprout | Green |
| popular | Popular | Flame | Orange |
| available-now | Available Now | Clock | Blue |

```vue
<script setup>
import AadiStatusBadge from './components/AadiStatusBadge.vue';
defineProps({ listing: { type: Object, required: true } });
</script>

<template>
  <AadiStatusBadge type="top-rated" :active="listing.is_top_rated === true" />
  <AadiStatusBadge type="featured" :active="listing.is_featured === true" />
  <AadiStatusBadge type="new" :active="listing.is_new === true" icon-style="outline" />
  <AadiStatusBadge type="popular" :active="listing.is_popular === true" />
  <AadiStatusBadge type="available-now" :active="listing.is_available_now === true" />
</template>
```

Field names above are examples. These components display backend-supplied statuses; they do not calculate ratings, popularity, newness, or availability. Set your own rating/review thresholds for Top Rated, placement rules for Featured, expiry window for New, activity criteria for Popular, and current availability for Available Now. Keep these independent of role verification, Plus, and Recommended.

| Prop | Values | Default |
| --- | --- | --- |
| type | Any type from the table above | Required |
| active | Boolean | false |
| iconStyle | outline / filled | filled |
| variant | pill / emblem / icon | pill |
| size | sm / md / lg | md |

Inactive badges and unknown types render nothing. Gray outline badges use transparent backgrounds; filled badges use solid colors and white symbols. The preview shows all five and applies the existing controls to the live listing badge section.

## Verified User

Use the existing `AadiVerifiedBadge` component with `role="user"`. A centered person icon and verification check identify general user verification. Outline is neutral gray; filled is solid cyan with a white person icon. All pill, emblem, and icon variants and sm/md/lg sizes are supported.

```vue
<AadiVerifiedBadge role="user" :verified="user.is_verified === true" icon-style="filled" />
```

`user.is_verified` is an example API field. General user verification should have its own backend status; it does not automatically grant verified landlord, vehicle-owner, or raketeer status. Omitted or false `verified` values hide the badge. The preview now includes a user alongside the three verified roles.
